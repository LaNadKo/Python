import math
a = -2
b = 0.8
h = 0.2
while a<b:
    Y=(a*math.cos(math.pi/4)-a**2)/(1-2*a*math.cos(math.pi/4)*a**2)
    print(Y)
    a=a+h

import telebot as tb
import random
bot = tb.TeleBot('6234691576:AAHcC7BpMAE8OVkp172Afh1TgWxYMolWqww')
creator_id = 839818502
colors=['1', '2', '3', '4', '5', '6', '7', '8', '9', '10+']
colorsreturn=[]
for item in colors:
    colorsreturn.append(item)
str=''
item=''
@bot.message_handler(commands=["start"])
def start(m, res=False):
    bot.send_message(m.chat.id, 'Нажмите 1 чтобы зарандомить:\nНажмите 2 чтобы добавить элемент:\nНажмите 3 ' 'чтобы удалить элемент:')
@bot.message_handler(content_types=["text"])
def handle_text(message):
    if message.text == '1':
        bot.send_message(message.chat.id, 'Я зарандомил: ' + RandomElement())
    if message.text == '2':
        bot.send_message(message.chat.id, 'Напишите цвет ')
        bot.register_next_step_handler(message, AddElement)
    if message.text == '3':
        bot.send_message(message.chat.id, 'Напишите цвет, который надо удалить')
        bot.register_next_step_handler(message, RemoveElement)
def RandomElement():
    if len(colorsreturn)!=0:
        index = random.randint(0, len(colorsreturn) - 1)
        str = colorsreturn[index]
        colorsreturn.remove(colorsreturn[index])
        return str
    else:
        for item in colors:
            colorsreturn.append(item)
        index = random.randint(0, len(colorsreturn) - 1)
        str = colorsreturn[index]
        colorsreturn.remove(colorsreturn[index])
        return str
def AddElement(message):
    global item
    item=message.text
    if not colors.__contains__(item):
        colors.append(item)
        colorsreturn.append(item)
        bot.send_message(message.from_user.id, f'Добавил чило {message.text}');
    else:
        bot.send_message(message.chat.id, f'Число {message.text} существует, напишите новый')
        bot.register_next_step_handler(message, AddElement)
def RemoveElement(message):
    global item
    item = message.text
    if colors.__contains__(item):
        colors.remove(item)
        colorsreturn.remove(item)
        bot.send_message(message.from_user.id, f'Удалил число {message.text}')
    else:
        bot.send_message(message.from_user.id, f'Числв не существует в списке, хотите добавлю?(Скажите да)');
        bot.register_next_step_handler(message, AddElement)
bot.polling(none_stop=True, interval=0)

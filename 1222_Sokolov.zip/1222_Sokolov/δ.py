string = input()
c = 0
for i in string:
    if i == "а":
        c+=1
r = string.replace('а', 'ф*')
print(f'Строка: {r}')
print(f'Замен произведено: {c}')
import math
x = input("x = ")
y = input("y = ")
z = input("z = ")
if x.isdigit() and y.isdigit() and z.isdigit():
    x = int(x)
    y = int(y)
    z = int(z)
    m = (min(z,x) + min(x, y))/max(x,y,z) ** 2
    print(m)

    if z < x:
        min1 = z
    else: min1 = x
    if x < y:
        min2 = x
    else: min2 = y
    if y>x and y>z:
        max1 = y
    elif x>y and x>z:
        max1 = x
    elif z>x and z>y:
        max1 = z
    m1 = (min1+min2)/max1 ** 2
    print(m1)
else:
    print("Ошибка, неверный тип данных")
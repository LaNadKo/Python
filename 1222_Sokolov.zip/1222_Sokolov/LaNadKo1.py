import telebot

# Создание экземпляра бота и передача токена вашего бота
bot = telebot.TeleBot('6234691576:AAHcC7BpMAE8OVkp172Afh1TgWxYMolWqww')

# ID создателя бота (ваш ID)
creator_id = 839818502

# Словарь для хранения ID пользователей
users = {}

# Обработка команды /start
@bot.message_handler(commands=['start'])
def handle_start(message):
    user_id = message.from_user.id
    if user_id not in users:
        users[user_id] = message.from_user.username
        bot.send_message(creator_id, f"Новый пользователь: {message.from_user.username} (ID: {user_id})")
    bot.send_message(message.chat.id, "Привет! Я бот, как могу помочь?")

# Обработка команды /scan
@bot.message_handler(commands=['scan'])
def handle_scan(message):
    if message.from_user.id == creator_id:
        user_count = len(users)
        bot.send_message(creator_id, f"Всего зарегистрировано пользователей: {user_count}")
    else:
        bot.reply_to(message, "У вас нет доступа к этой команде.")

@bot.message_handler(commands=['send'], content_types=['text'])
def handle_send(message):
    if message.from_user.id == creator_id:
        args = message.text.split(' ', maxsplit=2)
        if len(args) == 3:
            user_id = int(args[1])
            text = args[2]
            if user_id in users:
                bot.send_message(user_id, text)
                bot.send_message(creator_id, f"Сообщение отправлено пользователю (ID: {user_id})")
            else:
                bot.send_message(creator_id, f"Пользователь с ID {user_id} не зарегистрирован.")
        else:
            bot.send_message(creator_id, "Использование: /send <ID_пользователя> <сообщение>")
    else:
        bot.reply_to(message, "У вас нет доступа к этой команде.")

# Запуск бота
bot.polling()
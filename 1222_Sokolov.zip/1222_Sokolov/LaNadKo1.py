import math
z1 = 0
z2 = 1
while z1 != z2:
    a = int(input())
    z1 = 1 - 1/4 * (math.sin(2*a))** 2 + math.cos(2*a)
    z2 = (math.cos(a)**2)+(math.cos(a))**4
    print(z1, z2)
print("True")

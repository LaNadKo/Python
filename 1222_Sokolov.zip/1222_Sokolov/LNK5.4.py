a=0
b=0
def sum(x, y):
    print(f'a+b={x+y}')
def minus(x, y):
    print(f'a-b={x-y}')
def pr(x,y):
    print(f'a*b={x*y}')
def deli(x,y):
    try:
        print(f'a/b={x/y}')
    except ZeroDivisionError:
        print("Деление на ноль")
c = 1
while c !="0":
    print("Выберите какое вычесление вы хотите сделать: + or - or * or / ")
    c = input("Желаемое вычесление: ")
    if c=="+":
        a=int(input("Первое число: "))
        b=int(input("Второе число: "))
        sum(a,b)
    if c=="-":
        a=int(input("Первое число: "))
        b=int(input("Второе число: "))
        minus(a,b)
    if c=="*":
        a = int(input("Первое число: "))
        b = int(input("Второе число: "))
        pr(a,b)
    if c=="/":
        a = int(input("Первое число: "))
        b = int(input("Второе число: "))
        deli(x,y)
    if not(c=="+" or c=="-" or c=="*" or c=="/" or c=="0"):
        print("Введите нужный символ!")
print("Программа завершена.")

string = str(input())
if string.__len__()%2==0:
    string.split(" ")
    s=len(string)
    a=string[s/2:s]
    print(a.__reversed__())
else:
    string = string + "g"
    string.split(" ")
    s = len(string)
    a = string[s / 2:s]
    print(a.__reversed__())



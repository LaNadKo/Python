o=0
c = 1
N = 20
A = [0]*N
while c!=0:
    for i in range(N):
        A[i] = int(input())
    for i in range(A):
        if i==0:
            o+=1
    A.
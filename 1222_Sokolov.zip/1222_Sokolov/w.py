import math
x=int(input())
y=int(input())
z=int(input())
t=(2*math.cos(x-(math.pi/6))
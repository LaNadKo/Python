s=0
p=0
i=int(input())
p=i%10
while i>0:
    s+=i%10
    i=i//10
    p = p*(i%10)
print(s,p)
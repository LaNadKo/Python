import math
a=0.1
b=1
h=0.1
f=0
k=0
while a<b:
    S=(math.cos(k*a))/math.factorial(k)
    Y = (math.e ** math.cos(a)) * (math.cos(math.sin(a)))
    f+=S
    a+=h
    n = abs(Y-f)
print(f)
print(n)






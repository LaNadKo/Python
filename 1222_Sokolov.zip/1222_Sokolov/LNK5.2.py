n=int(input())
tr=0
f=0
while n>0:
    if n%2==0:
        tr+=1
    else:
        f+=1
    n=n//10
print("Чётные: ",tr, "Нечётные: ", f)
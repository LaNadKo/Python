c = 1
while c !="0":
    print("Выберите какое вычесление вы хотите сделать: + or - or * or / ")
    c = input("Желаемое вычесление: ")
    if c=="+":
        a=int(input("Первое число: "))
        b=int(input("Второе число: "))
        print("Ответ:", a + b)
    if c=="-":
        a=int(input("Первое число: "))
        b=int(input("Второе число: "))
        print("Ответ:", a - b)
    if c=="*":
        a = int(input("Первое число: "))
        b = int(input("Второе число: "))
        print("Ответ:", a * b)
    if c=="/":
        try:
            a = int(input("Первое число: "))
            b = int(input("Второе число: "))
            s = a / b
        except ZeroDivisionError:
            s = "деление на ноль"
        print("Ответ:", s)
    if not(c=="+" or c=="-" or c=="*" or c=="/"):
        print("Введите нужный символ!")
print("Программа завершена.")



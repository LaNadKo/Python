print(123//10)

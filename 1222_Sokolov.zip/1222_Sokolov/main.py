import math
import random
a=10
b=15
c=5.5
print(a+b)
print(a*b)
print(a**b)
print(math.factorial(a))
print(math.sqrt(b))
print(math.gamma(a))
print(math.sin(c))
print(math.radians(a*c))
print(math.exp(a))

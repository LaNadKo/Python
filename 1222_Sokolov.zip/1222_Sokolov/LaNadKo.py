isGood=True
print(isGood)

isAlive=False
print(isAlive)

myAge = input()
print("Возраст:", myAge)

myCount = input()
print("Количество:", myCount)
# import math
# z = int(input())
# if z < -1:
#     x = -z/3
# else:
#     x = abs(z)
# y = math.log(x + 0.5) + (math.exp(x) - math.exp(-x))
# print(y)
x = int(input("x = "))
y = int(input("y = "))
z = int(input("z = "))
m = (min(z,x) + min(x, y))/max(x,y,z) ** 2
print(m)

if z < x:
    min1 = z
else: min1 = x
if x < y:
    min2 = x
else: min2 = y
if y>x and y>z:
    max1 = y
elif x>y and x>z:
    max1 = x
elif z>x and z>y:
    max1 = z
m1 = (min1+min2)/max1 ** 2
print(m1)
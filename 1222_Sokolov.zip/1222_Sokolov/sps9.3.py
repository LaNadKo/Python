def to_list(*args):
    return list(args)
print(to_list(1,2,3))
print(to_list('a','b','c','d','e','f'))
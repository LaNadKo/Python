def nx(x, ev, od):
    if not x:
        return ev, od
    if x % 10 % 2 == 1:
        od += 1
    else:
        ev += 1
    return nx(x // 10, ev, od)
n = int(input())
print(nx(n, 0, 0))


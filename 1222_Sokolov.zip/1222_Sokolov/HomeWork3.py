import math
fi = 1
while fi != 0:
    x = input("x = ")
    y = input("y = ")
    z = input("z = ")
    try:
        x = int(x)
        y = int(y)
        z = int(z)
        fi = (math.e**(abs(x-y))*(abs(x-y)**(x+y)))/((math.cos(x)/math.sin(x))**(-1)+(math.cos(z)/math.sin(z))**(-1))+((x**6+(math.log(y)**2))**(1/3))
    except ZeroDivisionError:
        fi = "Деление на ноль"
    except ArithmeticError:
        fi = "Введите допустимые значения"
    except ValueError:
        fi = "Введите допустимые символы"
    except:
        print("Неизвестная ошибка, повторите заново введя число 1")
        fi = int(input())
    print("Ответ: ", fi)
    print("Для завершения программы введите 0")
    fi = int(input())


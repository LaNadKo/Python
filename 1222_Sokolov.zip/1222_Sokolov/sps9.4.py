def useless(s):
    maxn=max(s)
    l=len(s)
    return maxn/l

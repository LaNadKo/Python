import math
x = int(input())
y = int(input())
z = int(input())
fi = (math.exp(abs(x-y))*(abs(x-y)**(x+y)))/((math.cos(x)/math.sin(x))**(-1)+(math.cos(z)/math.sin(z))**(-1))+((x**6+(math.log(y)**2))**(1/3))
print(fi)